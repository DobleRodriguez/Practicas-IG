// #############################################################################
//
// Informática Gráfica (Grado Informática)
//
// Archivo: Malla3D.h
// -- declaraciones de clase Malla3D (mallas indexadas) y derivados
//
// #############################################################################

#ifndef MALLA3D_H_INCLUDED
#define MALLA3D_H_INCLUDED

#include "aux.h"
#include "material.h"

// *****************************************************************************
//
// clase para objetos 3D (mallas indexadas)
//
// *****************************************************************************

class Malla3D {
   public:

   // dibuja el objeto en modo inmediato
   void draw_ModoInmediato();

   // dibuja el objeto en modo diferido (usando VBOs)
   void draw_ModoDiferido();

   // función que redibuja el objeto
   // está función llama a 'draw_ModoInmediato' (modo inmediato)
   // o bien a 'draw_ModoDiferido' (modo diferido, VBOs)
   void draw(GLuint modo_dibujado) ;

   void setColor(Tupla3f color);
   void setColor(Tupla3f color, Tupla3f colorAjedrez);
   void setMaterial(Material mat);

   // GLuint modoDibujado = 2;   // Por defecto se dibuja en modo diferido
   
    bool sin_tapas = false;
    

   protected:

   void calcularNormales() ; // calcula tabla de normales de vértices (práctica 3)

   // tabla de coordenadas de vértices (una tupla por vértice, con tres floats)
   std::vector<Tupla3f> v ;  

   // una terna de 3 enteros por cada cara o triángulo
   std::vector<Tupla3i> f ; 

   // completar: tabla de colores, tabla de normales de vértices
   std::vector<Tupla3f> c;

   std::vector<Tupla3f> nv;

   Material m;
   Tupla3f color;
   Tupla3f colorAjedrez;

    unsigned f_tapas = 0;

   // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   GLuint id_vbo_ver = 0;     // Identificador de buffer de vértices
   GLuint id_vbo_tri = 0;     // Identificador de buffer de triángulos
   GLuint id_vbo_norm = 0;     // Identificador de buffer de colores
   GLuint CrearVBO(GLuint tipo_vbo, GLuint tamano_bytes, GLvoid* puntero_ram);
} ;


#endif
