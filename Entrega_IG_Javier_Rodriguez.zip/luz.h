#ifndef LUZ_H_INCLUDED
#define LUZ_H_INCLUDED

#include "aux.h"

class Luz {
    protected:
    unsigned id;
    const Tupla4f color_difuso = Tupla4f(1.0, 1.0, 0.85, 1.0);
    const Tupla4f color_especular = Tupla4f(1.0, 1.0, 0.85, 1.0);
    const Tupla4f color_ambiente = Tupla4f(1.0, 1.0, 1.0, 1.0);
    bool encendida;
    Tupla4f posicion;

    public:
    void activar();
    void desactivar();
    bool getEncendida();

} ;


#endif