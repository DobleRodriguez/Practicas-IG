
#include <algorithm>
#include "aux.h"     // includes de OpenGL/glut/glew, windows, y librería std de C++
#include "escena.h"
#include "malla.h" // objetos: Cubo y otros....

//**************************************************************************
// constructor de la escena (no puede usar ordenes de OpenGL)
//**************************************************************************

Escena::Escena() {
    Front_plane       = 50.0;
    Back_plane        = 2000.0;
    Observer_distance = 4*Front_plane;
    Observer_angle_x  = 0.0 ;
    Observer_angle_y  = 0.0 ;

    ejes.changeAxisSize( 5000 );

    glEnable(GL_CULL_FACE);
    glEnable(GL_NORMALIZE);
    cubo = new Cubo();
    tetraedro = new Tetraedro;
    cilindro = new Cilindro(21, 1, 0.5);
    cono = new Cono(20, 1, 0.5);
    esfera = new Esfera(20, 20, 1);
    ply = new ObjPLY("./plys/beethoven.ply");
    objRev = new ObjRevolucion("./plys/peon.ply", 20, true, true);
    luces.push_back(new LuzPosicional(Tupla3f(0, 5, 0), 0));
    luces.push_back(new LuzDireccional(Tupla2f(0, 0), 1));
}


//**************************************************************************
// inicialización de la escena (se ejecuta cuando ya se ha creado la ventana, por
// tanto sí puede ejecutar ordenes de OpenGL)
// Principalmemnte, inicializa OpenGL y la transf. de vista y proyección
//**************************************************************************

void Escena::inicializar( int UI_window_width, int UI_window_height ) {
    glClearColor( 1.0, 1.0, 1.0, 1.0 );// se indica cual sera el color para limpiar la ventana	(r,v,a,al)

    glEnable( GL_DEPTH_TEST );	// se habilita el z-bufer

    Width  = UI_window_width/10;
    Height = UI_window_height/10;

    change_projection( float(UI_window_width)/float(UI_window_height) );
    glViewport( 0, 0, UI_window_width, UI_window_height );
}



// **************************************************************************
//
// función de dibujo de la escena: limpia ventana, fija cámara, dibuja ejes,
// y dibuja los objetos
//
// **************************************************************************

void Escena::dibujar() {
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT ); // Limpiar la pantalla
    glDisable(GL_LIGHTING);
    change_observer();
    ejes.draw();
    if (!luces_activadas) {
        glEnable(GL_LIGHTING);
    } else {
        glDisable(GL_LIGHTING);
    }
    int i = 0,
        j = 0,
        k = 0,
        l = 0,
        factor_desp = 2;

    // Si existe figura
    glScalef(50, 50, 50);
    glShadeModel(iluminacion);

    if (figuras.empty()) {
        Material m = Material(
            Tupla4f(1.0, 0.55, 0.0, 0.9),
            Tupla4f(0.5, 0.0, 0.5, 0.5),
            Tupla4f(1.0, 0.55, 0.0, 0.9),
            1.0
        );
        glPushMatrix();
        glTranslatef(2, 0, 0);
        objRev -> setColor(Tupla3f(1.0, 1.0, 1.0));
        objRev -> setMaterial(Material(
            Tupla4f(1.0, 1.0, 1.0, 1.0),
            Tupla4f(0.0, 0.0, 0.0, 0.0),
            Tupla4f(1.0, 1.0, 1.0, 1.0),
            0.0
        ));
        objRev -> draw(modo_dibujado);
        glPopMatrix();
        glPushMatrix();
        glTranslatef(-2, 0, 0);
        objRev -> setColor(Tupla3f(0.0, 0.0, 0.0));
        objRev -> setMaterial(Material(
            Tupla4f(0.0, 0.0, 0.0, 1.0),
            Tupla4f(0.0, 0.0, 0.0, 1.0),
            Tupla4f(0.0, 0.0, 0.0, 1.0),
            1.0
        ));
        objRev -> draw(modo_dibujado);
        glPopMatrix();
        glPushMatrix();
        glTranslatef(0, 1, 0);
        cubo -> setColor(Tupla3f(1.0, 0.55, 0.0));
        cubo -> setMaterial(m);
        cubo -> draw(modo_dibujado);
        glPopMatrix();
    } else {

        for (Malla3D * figura : figuras) {
            glPushMatrix();
            glTranslatef(i, j, k);
            i += factor_desp;
            
            for (GLuint i : modosVis) {
                glPolygonMode(GL_FRONT_AND_BACK, i);
                // Se le asigna su color correspondiente
                switch (i) {
                case GL_POINT:
                    figura -> setColor(Tupla3f(1.0f, 0.55f, 0));
                    break;
                case GL_LINE:
                    figura -> setColor(Tupla3f(0.5f, 0, 0.5f));
                    break;
                case GL_FILL:
                    if (ajedrez) {
                        figura -> setColor(Tupla3f(0.82f, 0.82f, 0.82f), Tupla3f(0.33f, 0.33f, 0.33f));
                    } else {
                        figura -> setColor(Tupla3f(1.0f, 0.55f, 0));
                    }
                    break;
                }
                // Y se dibuja
                figura -> draw(modo_dibujado);
            }
            glPopMatrix();
        }

        /*}
        // if (figura != nullptr) {   
            // Para cada uno de los modos de visualización que se desean
            for (GLuint i : modosVis) {
                glPolygonMode(GL_FRONT_AND_BACK, i);
                // Se le asigna su color correspondiente
                switch (i) {
                case GL_POINT:
                    figura -> color = Tupla3f(1.0f, 0.55f, 0);
                    figura -> colorAjedrez = Tupla3f(1.0f, 0.55f, 0);
                    break;
                case GL_LINE:
                    figura -> color = Tupla3f(0.5f, 0, 0.5f);
                    figura -> colorAjedrez = Tupla3f(0.5f, 0, 0.5f);
                    break;
                case GL_FILL:
                    if (ajedrez) {
                        figura -> color = Tupla3f(0.82f, 0.82f, 0.82f);
                        figura -> colorAjedrez = Tupla3f(0.33f, 0.33f, 0.33f);
                    } else {
                        figura -> color = Tupla3f(1.0f, 0.55f, 0);
                        figura -> colorAjedrez = Tupla3f(1.0f, 0.55f, 0);
                    }
                    break;
                }
                // Y se dibuja
                figura -> draw(modo_dibujado);
            }
        }*/
    }
}

//**************************************************************************
//
// función que se invoca cuando se pulsa una tecla
// Devuelve true si se ha pulsado la tecla para terminar el programa (Q),
// devuelve false en otro caso.
//
//**************************************************************************

bool Escena::teclaPulsada( unsigned char tecla, int x, int y ) {
    using namespace std ;
    cout << "Tecla pulsada: '" << tecla << "'" << endl;
    bool salir=false;
    switch( toupper(tecla) ) {
    case 'Q' :
        if (modoMenu!=NADA) {
        modoMenu=NADA;            
        } else {
        salir=true ;
        }
        break ;

    // Modo de selección de objeto
    case 'O' :
        modoMenu=SELOBJETO; 
        break ; 

        // Objetos
        case 'C' :  // Cubo
        if (modoMenu == SELOBJETO) {
            set<Malla3D*>::iterator it;
            it = figuras.find(cubo);
            if (it == figuras.end()) {
                figuras.insert(cubo);
            } else {
                figuras.erase(cubo);
            }
        } else {
            std::cout << "Opción inválida" << endl;
        }
        break;

        case 'T' :  // Tetraedro
        if (modoMenu == SELOBJETO) {
            set<Malla3D*>::iterator it;
            it = figuras.find(tetraedro);
            if (it == figuras.end()) {
                figuras.insert(tetraedro);
            } else {
                figuras.erase(tetraedro);
            }
        } else if (modoMenu == SELVISUALIZACION) {
            for (Malla3D * figura : figuras) {
                figura -> sin_tapas = !figura -> sin_tapas;
            }
            dibujar();
        } else {
            std::cout << "Opción inválida" << endl;
        }
        break;


        case 'E' : // Esfera
        if (modoMenu == SELOBJETO) {
            set<Malla3D*>::iterator it;
            it = figuras.find(esfera);
            if (it == figuras.end()) {
                figuras.insert(esfera);
            } else {
                figuras.erase(esfera);
            }
        } else {
            std::cout << "Opción inválida" << endl;
        }
        break;

        case 'N' : // Cono
        if (modoMenu == SELOBJETO) {
            set<Malla3D*>::iterator it;
            it = figuras.find(cono);
            if (it == figuras.end()) {
                figuras.insert(cono);
            } else {
                figuras.erase(cono);
            }
        } else {
            std::cout << "Opción inválida" << endl;
        }
        break;

        case 'R' : // Cilindro
        if (modoMenu == SELOBJETO) {
            set<Malla3D*>::iterator it;
            it = figuras.find(cilindro);
            if (it == figuras.end()) {
                figuras.insert(cilindro);
            } else {
                figuras.erase(cilindro);
            }
        } else {
            std::cout << "Opción inválida" << endl;
        }
        break;

        case 'J' : // ObjRevolucionPLY
        if (modoMenu == SELOBJETO) {
            set<Malla3D*>::iterator it;
            it = figuras.find(objRev);
            if (it == figuras.end()) {
                figuras.insert(objRev);
            } else {
                figuras.erase(objRev);
            }
        } else {
            std::cout << "Opción inválida" << endl;
        }
        break;

        case 'Y' : // ObjPLY
        if (modoMenu == SELOBJETO) {
            set<Malla3D*>::iterator it;
            it = figuras.find(ply);
            if (it == figuras.end()) {
                figuras.insert(ply);
            } else {
                figuras.erase(ply);
            }
        } else {
            std::cout << "Opción inválida" << endl;
        }
        break;


    // Modo de selección de visualización
    case 'V' :
        modoMenu=SELVISUALIZACION;
        break ;

        // Modos de visualización
        case 'P' :  // Puntos
        if (modoMenu == SELVISUALIZACION) {
            //luces_activadas = false;
            iluminacion = GL_FLAT;
            set<GLuint>::iterator it;
            it = modosVis.find(GL_POINT);
            if (it == modosVis.end()) {
                modosVis.insert(GL_POINT);
            } else {
                modosVis.erase(GL_POINT);
            }
            dibujar();
        } else {
            std::cout << "Opción inválida" << endl;
        }
        break;
        
        case 'L' :  // Líneas
        if (modoMenu == SELVISUALIZACION) {
            //luces_activadas = false;
            iluminacion = GL_FLAT;
            set<GLuint>::iterator it;
            it = modosVis.find(GL_LINE);
            if (it == modosVis.end()) {
                modosVis.insert(GL_LINE);
            } else {
                modosVis.erase(GL_LINE);
            }
            dibujar();
        } else {
            std::cout << "Opción inválida" << endl;
        }
        break;

        case 'S' :  // Sólido
        if (modoMenu == SELVISUALIZACION) {
            //luces_activadas = false;
            iluminacion = GL_FLAT;
            set<GLuint>::iterator it;
            it = modosVis.find(GL_FILL);
            if (it == modosVis.end()) {
                modosVis.insert(GL_FILL);
                ajedrez = false;
            } else {
                if (!ajedrez) {
                    modosVis.erase(GL_FILL);
                } else {
                    ajedrez = false;
                }
            }
            dibujar();
        } else {
            std::cout << "Opción inválida" << endl;
        }
        break;

        case 'A' :  // Ajedrez
        if (modoMenu == SELVISUALIZACION) {
            //luces_activadas = false;
            iluminacion = GL_FLAT;
            set<GLuint>::iterator it;
            it = modosVis.find(GL_FILL);
            if (it == modosVis.end()) {
                modosVis.insert(GL_FILL);
                ajedrez = true;
            } else {
                if (ajedrez) {
                    modosVis.erase(GL_FILL);
                } else {
                    ajedrez = true;
                }
            }
            dibujar();
        } else {
            std::cout << "Opción inválida" << endl;
        }
        break;

        case 'I' : // Iluminación
        if (modoMenu == SELVISUALIZACION) {
            if (iluminacion == GL_SMOOTH) {
                iluminacion = GL_FLAT;
                //luces_activadas = false;
                for (Luz * i : luces) {
                    i -> desactivar();
                }
            } else {
                iluminacion = GL_SMOOTH;
                /*luces_activadas = true;
                for (Luz * i : luces) {
                    i -> activar();
                }*/
            }
        } 
        break;

    // Modo de selección de dibujado
    case 'D' :
        modoMenu=SELDIBUJADO;
        break ;

        case '0': // Luz 0
        if (modoMenu == SELVISUALIZACION && luces_activadas) {
            if (!luces[0] -> getEncendida()) {
                luces[0] -> activar();
            } else {
                luces[0] -> desactivar();
            }
        } else {
            std::cout << "Opción inválida" << endl;  
        }
        break;

        case '1' :  // Inmediato | Luz 1
        if (modoMenu == SELDIBUJADO) {
            modo_dibujado = 1;
            dibujar();
        } else if (modoMenu == SELVISUALIZACION && luces_activadas) {
            if (!luces[1] -> getEncendida()) {
                luces[1] -> activar();
            } else {
                luces[1] -> desactivar();
            }
        } else {
            std::cout << "Opción inválida" << endl;  
        } 
        break;
        
        case '2' :  // Diferido
        if (modoMenu == SELDIBUJADO) {
            modo_dibujado = 2;
            dibujar();
        } else if (modoMenu == SELVISUALIZACION && luces_activadas) {
            if (!luces[2] -> getEncendida()) {
                luces[2] -> activar();
            } else {
                luces[2] -> desactivar();
            }
        } else {
            std::cout << "Opción inválida" << endl;  
        } 
        break;

        case '3': // Luz 0
        if (modoMenu == SELVISUALIZACION && luces_activadas) {
            if (!luces[3] -> getEncendida()) {
                luces[3] -> activar();
            } else {
                luces[3] -> desactivar();
            }
        } else {
            std::cout << "Opción inválida" << endl;  
        }
        break;
    
        case '4': // Luz 0
        if (modoMenu == SELVISUALIZACION && luces_activadas) {
            if (!luces[4] -> getEncendida()) {
                luces[4] -> activar();
            } else {
                luces[4] -> desactivar();
            }
        } else {
            std::cout << "Opción inválida" << endl;  
        }
        break;

        case '5': // Luz 0
        if (modoMenu == SELVISUALIZACION && luces_activadas) {
            if (!luces[5] -> getEncendida()) {
                luces[5] -> activar();
            } else {
                luces[5] -> desactivar();
            }
        } else {
            std::cout << "Opción inválida" << endl;  
        }
        break;

        case '6': // Luz 0
        if (modoMenu == SELVISUALIZACION && luces_activadas) {
            if (!luces[6] -> getEncendida()) {
                luces[6] -> activar();
            } else {
                luces[6] -> desactivar();
            }
        } else {
            std::cout << "Opción inválida" << endl;  
        }
        break;

        case '7': // Luz 0
        if (modoMenu == SELVISUALIZACION && luces_activadas) {
            if (!luces[7] -> getEncendida()) {
                luces[7] -> activar();
            } else {
                luces[7] -> desactivar();
            }
        } else {
            std::cout << "Opción inválida" << endl;  
        }
        break;

    default:
    std::cout << "Opción inválida" << endl;
    break;

   }

    /*switch(modoMenu) {
        case NADA :
        switch (toupper(tecla)) {
            case 'Q' :
            salir = true;
            break;
            
            case 'O' :
            modoMenu = SELOBJETO;
            break;

            case 'V' :
            modoMenu = SELVISUALIZACION;
            break;

            case 'D' :
            modoMenu = SELDIBUJADO;
            break;
            
            default :
            std::cout << "Opción inválida" << std::endl;
            break;
        }
        break;

        case SELOBJETO :
        set<Malla3D *>::iterator ito; 
        switch (toupper(tecla)) {
            case 'C' :  // Cubo
            ito = figuras.find(cubo);
            if (ito == figuras.end()) {
                figuras.insert(cubo);
            } else {
                figuras.erase(cubo);
            }
            break;

            case 'T' :  // Tetraedro
            ito = figuras.find(tetraedro);
            if (ito == figuras.end()) {
                figuras.insert(tetraedro);
            } else {
                figuras.erase(tetraedro);
            }
            break;

            case 'E' : // Esfera
            ito = figuras.find(esfera);
            if (ito == figuras.end()) {
                figuras.insert(esfera);
            } else {
                figuras.erase(esfera);
            }
            break;

            case 'N' : // Cono
            ito = figuras.find(cono);
            if (ito == figuras.end()) {
                figuras.insert(cono);
            } else {
                figuras.erase(cono);
            }
            break;

            case 'D' : // Cilindro
            ito = figuras.find(cilindro);
            if (ito == figuras.end()) {
                figuras.insert(cilindro);
            } else {
                figuras.erase(cilindro);
            }
            break;

            case 'R' : // ObjRevolucionPLY
            ito = figuras.find(objRev);
            if (ito == figuras.end()) {
                figuras.insert(objRev);
            } else {
                figuras.erase(objRev);
            }
            break;

            case 'Y' : // ObjPLY
            ito = figuras.find(ply);
            if (ito == figuras.end()) {
                figuras.insert(ply);
            } else {
                figuras.erase(ply);
            }
            break;

            case 'Q' :
            modoMenu = NADA;
            break;

            default:
            std::cout << "Opción inválida" << std::endl;
            break;
        }
        break;

        case SELVISUALIZACION:
        switch(toupper(tecla)) {
            set<GLuint>::iterator itv;
            case 'P' :  // Puntos
            itv = modosVis.find(GL_POINT);
            if (itv == modosVis.end()) {
                modosVis.insert(GL_POINT);
            } else {
                modosVis.erase(GL_POINT);
            }
            dibujar();
            break;
            
            case 'L' :  // Líneas
            itv = modosVis.find(GL_LINE);
            if (itv == modosVis.end()) {
                modosVis.insert(GL_LINE);
            } else {
                modosVis.erase(GL_LINE);
            }
            dibujar();
            break;

            case 'S' :  // Sólido
            itv = modosVis.find(GL_FILL);
            if (itv == modosVis.end()) {
                modosVis.insert(GL_FILL);
                ajedrez = false;
            } else {
                if (!ajedrez) {
                    modosVis.erase(GL_FILL);
                } else {
                    ajedrez = false;
                }
            }
            dibujar();
            break;

            case 'A' :  // Ajedrez
            itv = modosVis.find(GL_FILL);
            if (itv == modosVis.end()) {
                modosVis.insert(GL_FILL);
                ajedrez = true;
            } else {
                if (ajedrez) {
                    modosVis.erase(GL_FILL);
                } else {
                    ajedrez = true;
                }
            }
            dibujar();
            break;

            case 'Q' :
            modoMenu = NADA;
            break;

            default:
            std::cout << "Opción inválida" << std::endl;
            break;
        }
        break;

        case SELDIBUJADO:
        switch(toupper(tecla)) {
            case '1' :  // Inmediato
            modo_dibujado = 1;
            dibujar();
            break;
            
            case '2' :  // Diferido
            modo_dibujado = 2;
            dibujar();
            break;

            case '3' : // Tapas
            for (Malla3D * figura : figuras) {
                figura -> sin_tapas = !figura -> sin_tapas;
            }
            dibujar();
            break;

            case 'Q' :
            modoMenu = NADA;
            break;

            default:
            std::cout << "Opción inválida" << std::endl;
            break;
        }
        break;
    }*/
   return salir;
}
//**************************************************************************

void Escena::teclaEspecial( int Tecla1, int x, int y )
{
   switch ( Tecla1 )
   {
	   case GLUT_KEY_LEFT:
         Observer_angle_y-- ;
         break;
	   case GLUT_KEY_RIGHT:
         Observer_angle_y++ ;
         break;
	   case GLUT_KEY_UP:
         Observer_angle_x-- ;
         break;
	   case GLUT_KEY_DOWN:
         Observer_angle_x++ ;
         break;
	   case GLUT_KEY_PAGE_UP:
         Observer_distance *=1.2 ;
         break;
	   case GLUT_KEY_PAGE_DOWN:
         Observer_distance /= 1.2 ;
         break;
	}

	//std::cout << Observer_distance << std::endl;
}

//**************************************************************************
// Funcion para definir la transformación de proyeccion
//
// ratio_xy : relacción de aspecto del viewport ( == ancho(X) / alto(Y) )
//
//***************************************************************************

void Escena::change_projection( const float ratio_xy )
{
   glMatrixMode( GL_PROJECTION );
   glLoadIdentity();
   const float wx = float(Height)*ratio_xy ;
   glFrustum( -wx, wx, -Height, Height, Front_plane, Back_plane );
}
//**************************************************************************
// Funcion que se invoca cuando cambia el tamaño de la ventana
//***************************************************************************

void Escena::redimensionar( int newWidth, int newHeight )
{
   Width  = newWidth/10;
   Height = newHeight/10;
   change_projection( float(newHeight)/float(newWidth) );
   glViewport( 0, 0, newWidth, newHeight );
}

//**************************************************************************
// Funcion para definir la transformación de vista (posicionar la camara)
//***************************************************************************

void Escena::change_observer()
{
   // posicion del observador
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   glTranslatef( 0.0, 0.0, -Observer_distance );
   glRotatef( Observer_angle_y, 0.0 ,1.0, 0.0 );
   glRotatef( Observer_angle_x, 1.0, 0.0, 0.0 );
}
