#include "aux.h"
#include "malla.h"

// *****************************************************************************
//
// Clase Malla3D
//
// *****************************************************************************

// Visualización en modo inmediato con 'glDrawElements'

void Malla3D::draw_ModoInmediato() {
  // Habilitar uso de array de vértices
   glEnableClientState(GL_VERTEX_ARRAY);
   glEnableClientState(GL_NORMAL_ARRAY);
   glEnableClientState(GL_COLOR_ARRAY);
  // Formato y dirección de memoria del array
   glVertexPointer(3, GL_FLOAT, 0, v.data());
   glNormalPointer(GL_FLOAT, 0, nv.data());
   glColorPointer(3, GL_FLOAT, 0, c.data());
  // Visualizar, indicando tipo de primitiva, # índices, típo indices y dirección de la tabla
   glDrawElements(GL_TRIANGLES, (f.size() - (f_tapas * sin_tapas)) * 3, GL_UNSIGNED_INT, f.data());
  // Deshabilitar array de vértices
   glDisableClientState(GL_COLOR_ARRAY);
   glDisableClientState(GL_VERTEX_ARRAY);
}
// -----------------------------------------------------------------------------
// Visualización en modo diferido con 'glDrawElements' (usando VBOs)

void Malla3D::draw_ModoDiferido() {
   // Comprobar que los VBO existen. Si no, crear
   if (id_vbo_ver == 0) {
      id_vbo_ver = CrearVBO(GL_ARRAY_BUFFER, v.size() * sizeof(Tupla3f), v.data());
   }
   if (id_vbo_tri == 0) {
      id_vbo_tri = CrearVBO(GL_ELEMENT_ARRAY_BUFFER, f.size()*sizeof(Tupla3i), f.data());
   }
   if (id_vbo_norm == 0) {
      id_vbo_norm = CrearVBO(GL_ARRAY_BUFFER, nv.size() * sizeof(Tupla3f), nv.data());
   }
   // Especificar localización y formato de la tabla de vértices, habilitar
   glBindBuffer(GL_ARRAY_BUFFER, id_vbo_ver); // Activar VBO vértices
   glVertexPointer(3, GL_FLOAT, 0, 0); // Especificar formato y offset
   glBindBuffer(GL_ARRAY_BUFFER, 0); // Desactivar VBO de vértices
   glBindBuffer(GL_ARRAY_BUFFER, id_vbo_norm);
   glNormalPointer(GL_FLOAT, 0, 0);
   glBindBuffer(GL_ARRAY_BUFFER, 0);
   glEnableClientState(GL_VERTEX_ARRAY); // Habilitar tabla de vértices
   glEnableClientState(GL_NORMAL_ARRAY);
   glEnableClientState(GL_COLOR_ARRAY);
   glColorPointer(3, GL_FLOAT, 0, c.data());
   // Visualizar triágulos con glDrawElements
   glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, id_vbo_tri);
   glDrawElements(GL_TRIANGLES,  (f.size() - (f_tapas * sin_tapas)) * 3, GL_UNSIGNED_INT, 0);
   glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
   glDisableClientState(GL_COLOR_ARRAY);
   glEnableClientState(GL_NORMAL_ARRAY);
   glDisableClientState(GL_VERTEX_ARRAY);
}
// -----------------------------------------------------------------------------
// Función de visualización de la malla,
// puede llamar a  draw_ModoInmediato o bien a draw_ModoDiferido

void Malla3D::draw(GLuint modo_dibujado) {
   c.clear();

   m.aplicar();

   if (nv.empty()) {
      calcularNormales();
   }
   // Determina modo de dibujado
   switch (modo_dibujado) {
      case 1:
         draw_ModoInmediato();
         break;
      case 2:
         draw_ModoDiferido();
         break;
   }

}

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
GLuint Malla3D::CrearVBO(GLuint tipo_vbo, GLuint tamano_bytes, GLvoid* puntero_ram) {
   // ID a generar. Valor de retorno
   GLuint id_vbo;
   // Generar VBO, recibir ID
   glGenBuffers(1, &id_vbo);
   // Activar VBO mediante ID
   glBindBuffer(tipo_vbo, id_vbo);
   // Transferir datos de RAM a GPU
   glBufferData(tipo_vbo, tamano_bytes, puntero_ram, GL_STATIC_DRAW);
   glBindBuffer(tipo_vbo, 0);
   return id_vbo;
}

void Malla3D::calcularNormales() {
   nv.reserve(v.size());
   Tupla3f a,
           b,
           u;
   for(unsigned i = 0; i < f.size(); i++) {
      a = v[f[i](1)] - v[f[i](0)];
      b = v[f[i](2)] - v[f[i](0)];
      u =  a.cross(b).normalized();
      nv[f[i](0)] = u + nv[f[i](0)];
      nv[f[i](1)] = u + nv[f[i](1)];
      nv[f[i](2)] = u + nv[f[i](2)];
   }
   for (Tupla3f i : nv) {
      i = i.normalized();
   }
}

void Malla3D::setMaterial(Material mat) {
   m = mat;
}

void Malla3D::setColor(Tupla3f color) {
   for (unsigned i = 0; i < v.size(); i++) {
      c.push_back(color);
   }
}

void Malla3D::setColor(Tupla3f color, Tupla3f colorAjedrez) {
   for (GLuint i = 0; i < v.size(); i++) {
      if (i % 2 == 0) {
         c.push_back(color);
      } else {
         c.push_back(colorAjedrez);
      }
   }
}
