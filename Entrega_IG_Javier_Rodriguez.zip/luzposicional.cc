#include "aux.h"
#include "luzposicional.h"

LuzPosicional::LuzPosicional(const Tupla3f &posicion, const unsigned id) {
    this->posicion = Tupla4f(posicion(X), posicion(Y), posicion(Z), 1);
    glLightfv(GL_LIGHT0 + id, GL_DIFFUSE, color_difuso);
    glLightfv(GL_LIGHT0 + id, GL_SPECULAR, color_especular);
    glLightfv(GL_LIGHT0 + id, GL_AMBIENT, color_ambiente);
    glLightfv(GL_LIGHT0 + id, GL_POSITION, posicion);
    this -> id = id;
}

