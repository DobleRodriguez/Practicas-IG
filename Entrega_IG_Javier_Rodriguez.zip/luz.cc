#include "aux.h"
#include "luz.h"


void Luz::activar() {
    glEnable(id);
    encendida = true;
}

void Luz::desactivar() {
    glDisable(id);
    encendida = false;
}

bool Luz::getEncendida() {
    return encendida;
}