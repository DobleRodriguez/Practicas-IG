#include "aux.h"
#include "luz.h"
#include "luzdireccional.h"

LuzDireccional::LuzDireccional(const Tupla2f &orientacion, const unsigned id) {
    alpha = orientacion(0);
    beta = orientacion(1);
    calcularPosicion();
    glLightfv(GL_LIGHT0 + id, GL_DIFFUSE, color_difuso);
    glLightfv(GL_LIGHT0 + id, GL_SPECULAR, color_especular);
    glLightfv(GL_LIGHT0 + id, GL_AMBIENT, color_ambiente);
    glLightfv(GL_LIGHT0 + id, GL_POSITION, posicion);
    this -> id = id;
}


void LuzDireccional::variarAnguloAlpha(float incremento) {
    alpha += incremento;
    calcularPosicion();
}

void LuzDireccional::variarAnguloBeta(float incremento) {
    beta += incremento;
    calcularPosicion();
}

void LuzDireccional::calcularPosicion() {
    posicion = Tupla4f(
        sin(alpha) * cos(beta),
        sin(alpha) * sin(beta),
        cos(alpha),
        0
    );
}
