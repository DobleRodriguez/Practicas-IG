#ifndef RECTANGULO_H_INCLUDED
#define RECTANGULO_H_INCLUDED

#include "aux.h"

class Rectangulo : public Malla3D {
   public:
   Rectangulo(float ancho, float alto) ;
} ;




#endif
