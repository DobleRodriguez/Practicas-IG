#ifndef TRAPECIO_H_INCLUDED
#define TRAPECIO_H_INCLUDED

#include "aux.h"
#include "malla.h"

class Trapecio : public Malla3D {
   public:
   Trapecio() ;
} ;




#endif
